/*
* CSF Assignment 5
* Network Calculator
* Function implementations
* Simone Bliss & Danny Lee
* sbliss5@jhu.edu, jlee692@jhu.edu
*/

#include <map>
#include <string>
#include <vector>
#include <iostream>
#include <sstream>
#include "calc.h"

using std::cout; using std::cin; using std::cerr; 
using std::endl; using std::stringstream;
using std::map; using std::string; using std::vector;

struct Calc {
};

class CalcImpl : public Calc {
    // code...
    public:
        int evalExpr(const char *expr, int *result);
        map<string, int> dictionary; //check syntax
};

int CalcImpl::evalExpr(const char *expr, int *result) {
    
    return 0;
}


extern "C" struct Calc *calc_create(void) {
    return new CalcImpl();
}

extern "C" void calc_destroy(struct Calc *calc) {
    CalcImpl *obj = static_cast<CalcImpl *>(calc);
    delete obj;
}

extern "C" int calc_eval(struct Calc *calc, const char *expr, int *result) {
    CalcImpl *obj = static_cast<CalcImpl *>(calc);
    return obj->evalExpr(expr, result);
}

//do i need to define this in the h file? if so, how?
//also no  exactly sure how  this  works
vector<string> tokenize(const string &expr) { 
    vector<string> vec;
    stringstream s(expr);
    string token; 
    while (s >> token) {
        vec.push_back(token); 
    }
    return vec; 
}



